import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Code2, History, MessageSquareText, MonitorSmartphone, Rocket, ShieldCheck, Wand2, Zap } from "lucide-react";

import { PromptBox } from "@/components/nzf/prompt-box";
import { SiteFooter, SiteHeader } from "@/components/nzf/site-header";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "NZF IA — Crie páginas de marketing digital conversando" },
      {
        name: "description",
        content: "Descreva sua ideia e a NZF IA cria landing pages, páginas de vendas e captura prontas em segundos.",
      },
      { property: "og:title", content: "NZF IA — Crie páginas de marketing digital conversando" },
      {
        property: "og:description",
        content: "Descreva sua ideia e a NZF IA cria landing pages, páginas de vendas e captura prontas em segundos.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const STEPS = [
  { icon: MessageSquareText, title: "Descreva", text: "Conte o que você quer vender ou divulgar, do seu jeito." },
  { icon: Wand2, title: "A IA cria", text: "A NZF IA escreve os textos, monta o design e entrega a página pronta." },
  { icon: Rocket, title: "Ajuste e publique", text: "Peça mudanças no chat, baixe o arquivo e coloque no ar." },
];

const FEATURES = [
  { icon: Zap, title: "Prévia ao vivo", text: "Veja a página sendo construída enquanto a IA escreve." },
  { icon: MonitorSmartphone, title: "Celular, tablet e PC", text: "Confira como fica em cada tela com um clique." },
  { icon: History, title: "Histórico de versões", text: "Volte para qualquer versão anterior quando quiser." },
  { icon: Code2, title: "Código na mão", text: "Copie ou baixe o HTML e hospede onde preferir." },
  { icon: Wand2, title: "Copy que converte", text: "Headlines, ofertas, FAQ e chamadas pensadas para vender." },
  { icon: ShieldCheck, title: "Com responsabilidade", text: "Bloqueia golpes, phishing e promessas enganosas." },
];

function Index() {
  return (
    <div className="min-h-screen overflow-x-hidden">
      <SiteHeader />
      <main>
        <section className="relative">
          <div className="pointer-events-none absolute inset-0 bg-hero-glow" aria-hidden />
          <div className="pointer-events-none absolute inset-0 bg-grid" aria-hidden />
          <div
            className="pointer-events-none absolute -top-20 left-1/2 size-[520px] -translate-x-1/2 animate-float rounded-full bg-gradient-brand opacity-20 blur-3xl"
            aria-hidden
          />
          <div className="relative mx-auto flex max-w-3xl flex-col items-center px-5 pb-24 pt-20 text-center sm:pt-28">
            <span className="animate-rise mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-foreground/5 px-3 py-1 text-xs text-muted-foreground">
              <span className="size-1.5 rounded-full bg-primary" /> A IA de páginas do NZF
            </span>
            <h1 className="animate-rise text-5xl font-extrabold leading-[1.02] sm:text-7xl">
              Fale sua ideia.
              <br />
              <span className="text-gradient-brand">Ganhe uma página.</span>
            </h1>
            <p className="animate-rise mt-6 max-w-xl text-lg text-muted-foreground [animation-delay:120ms]">
              A NZF IA cria landing pages, páginas de vendas e de captura completas — com textos, design e tudo
              funcionando — só conversando.
            </p>
            <div className="animate-rise mt-10 w-full [animation-delay:220ms]">
              <PromptBox />
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-5 py-20">
          <div className="mb-12 max-w-xl">
            <p className="font-mono text-xs uppercase tracking-widest text-primary">Como funciona</p>
            <h2 className="mt-3 text-4xl font-bold sm:text-5xl">Do pedido ao ar em três passos.</h2>
          </div>
          <div className="grid gap-4 md:grid-cols-3">
            {STEPS.map((s, i) => (
              <div key={s.title} className="rounded-2xl border border-border bg-card p-6">
                <div className="flex items-center justify-between">
                  <s.icon className="size-6 text-primary" />
                  <span className="font-mono text-sm text-muted-foreground">0{i + 1}</span>
                </div>
                <h3 className="mt-8 text-2xl font-bold">{s.title}</h3>
                <p className="mt-2 text-muted-foreground">{s.text}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-5 pb-20">
          <div className="grid gap-px overflow-hidden rounded-3xl border border-border bg-border sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((f) => (
              <div key={f.title} className="bg-surface p-7 transition-colors hover:bg-surface-raised">
                <f.icon className="size-5 text-accent" />
                <h3 className="mt-5 text-lg font-semibold">{f.title}</h3>
                <p className="mt-1.5 text-sm text-muted-foreground">{f.text}</p>
              </div>
            ))}
          </div>
          <div className="mt-6 text-center">
            <Button asChild variant="link">
              <Link to="/recursos">
                Ver todos os recursos <ArrowRight />
              </Link>
            </Button>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-5 pb-24">
          <div className="relative overflow-hidden rounded-3xl border border-border bg-card px-8 py-16 text-center">
            <div className="pointer-events-none absolute inset-0 bg-hero-glow opacity-80" aria-hidden />
            <h2 className="relative text-4xl font-extrabold sm:text-5xl">
              Sua próxima página <span className="text-gradient-brand">começa agora.</span>
            </h2>
            <p className="relative mx-auto mt-4 max-w-md text-muted-foreground">
              Escolha um modelo ou escreva do zero. Seus projetos ficam salvos neste navegador.
            </p>
            <Button asChild variant="hero" size="xl" className="relative mt-8">
              <Link to="/projetos">
                Abrir meus projetos <ArrowRight />
              </Link>
            </Button>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
